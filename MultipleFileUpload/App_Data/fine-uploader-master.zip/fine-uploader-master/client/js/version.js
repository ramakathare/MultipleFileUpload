/*global qq */
qq.version = "5.1.3";
