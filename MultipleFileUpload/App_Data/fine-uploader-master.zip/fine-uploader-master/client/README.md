Do not add files from this directory into your project.  Please visit the
downloads page for zips that contain combined and version-stamped javascript
and css files, along with all required resources.

# Download
To download a pre-packaged version of Fine Uploader visit: http://fineuploader.com/downloads.html

# Build
For instructions on building your own packaged version of Fine Uploader visit: http://docs.fineuploader.com/contributing.htm

